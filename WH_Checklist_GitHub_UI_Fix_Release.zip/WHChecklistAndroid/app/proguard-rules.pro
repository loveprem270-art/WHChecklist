# Keep empty for this app; minification is disabled for debug and release in this first build.
