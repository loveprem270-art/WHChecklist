package com.whchecklist.app

data class ChecklistItem(
    val no: Int,
    val category: String,
    val frequency: String,
    val text: String,
    val actualTemplate: String = "Enter actual status details (Yes/No, %, quantity, date, value or other field shown in source)"
)

data class Response(
    val status: String = "Pending", // Pending / Yes / No / N/A
    val actual: String = "",
    val remarks: String = "",
    val gap: String = "",
    val action: String = "",
    val responsible: String = "",
    val targetDate: String = "",
    val closure: String = "Open",
    val photoPath: String? = null
)

data class SelfCheck(
    val id: Long, val date: String, val unit: String, val user: String, val type: String,
    val status: String, val total: Int, val completed: Int, val pass: Int, val fail: Int,
    val na: Int, val pending: Int, val compliance: Double
)
