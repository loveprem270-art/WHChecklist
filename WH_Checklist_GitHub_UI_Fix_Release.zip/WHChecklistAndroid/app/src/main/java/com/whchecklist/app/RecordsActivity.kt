package com.whchecklist.app

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import java.util.*

class RecordsActivity:AppCompatActivity(){
    private lateinit var db:DbHelper
    private lateinit var container:LinearLayout
    private lateinit var search:EditText
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_records);db=DbHelper(this);container=findViewById(R.id.container);search=findViewById(R.id.etSearch);findViewById<TextView>(R.id.btnBack).setOnClickListener{finish()};findViewById<Button>(R.id.btnRefresh).setOnClickListener{render()};search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?) {}});render()}
    private fun render(){container.removeAllViews();val q=search.text.toString().trim().lowercase(Locale.getDefault());db.listSelfChecks().filter{q.isBlank()||it.unit.lowercase().contains(q)||it.user.lowercase().contains(q)||it.date.lowercase().contains(q)}.forEach{sc->
        val card=MaterialCardView(this).apply{useCompatPadding=true;radius=12f}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14)}
        root.addView(TextView(this).apply{text="${sc.date}  •  ${sc.unit}";textSize=16f;setTypeface(typeface,1)})
        root.addView(TextView(this).apply{text="${sc.user}  •  ${sc.type}";textSize=12f;setTextColor(android.graphics.Color.DKGRAY);setPadding(0,4,0,6)})
        root.addView(TextView(this).apply{text="${sc.completed}/${sc.total} complete   PASS ${sc.pass}   FAIL ${sc.fail}   Pending ${sc.pending}   Compliance ${String.format("%.1f",sc.compliance)}%";textSize=12f})
        val b=Button(this).apply{text="OPEN";setOnClickListener{startActivity(android.content.Intent(this@RecordsActivity,SelfCheckActivity::class.java).putExtra("selfCheckId",sc.id))}}
        root.addView(b);card.addView(root);container.addView(card)
    }
    }
}
