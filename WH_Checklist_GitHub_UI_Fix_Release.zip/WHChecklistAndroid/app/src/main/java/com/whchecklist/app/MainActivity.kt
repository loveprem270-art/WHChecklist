package com.whchecklist.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity(){
    private lateinit var db:DbHelper
    override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_main);db=DbHelper(this); refresh();
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnNew).setOnClickListener{startActivity(Intent(this,SelfCheckActivity::class.java))}
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnRecords).setOnClickListener{startActivity(Intent(this,RecordsActivity::class.java))}
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnReports).setOnClickListener{startActivity(Intent(this,ReportsActivity::class.java))}
    }
    private fun refresh(){
        val list=db.listSelfChecks(); val last=list.firstOrNull()
        findViewById<android.widget.TextView>(R.id.tvLastCompliance).text=last?.let{"${String.format("%.1f",it.compliance)}%"} ?: "0%"
        findViewById<android.widget.TextView>(R.id.tvPending).text=last?.pending?.toString() ?: "0"
        findViewById<android.widget.TextView>(R.id.tvOpenActions).text=last?.fail?.toString() ?: "0"
    }
    override fun onResume(){super.onResume(); if(::db.isInitialized) refresh()}
}
