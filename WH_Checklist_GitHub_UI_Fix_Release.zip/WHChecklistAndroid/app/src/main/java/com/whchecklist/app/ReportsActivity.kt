package com.whchecklist.app

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.*

class ReportsActivity:AppCompatActivity(){
    private lateinit var db:DbHelper; private lateinit var container:LinearLayout; private lateinit var period:Spinner; private lateinit var category:Spinner
    private val cats=listOf("All")+ChecklistData.items.map{it.category}.distinct()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_reports);db=DbHelper(this);container=findViewById(R.id.container);period=findViewById(R.id.spPeriod);category=findViewById(R.id.spCategory);findViewById<TextView>(R.id.btnBack).setOnClickListener{finish()}
        period.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("All","Today","This Week","This Month","This Quarter","This Year"));category.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats)
        val l=object:AdapterView.OnItemSelectedListener{override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){render()};override fun onNothingSelected(p:AdapterView<*>?) {}};period.onItemSelectedListener=l;category.onItemSelectedListener=l;render()
    }
    private fun render(){container.removeAllViews(); val records=db.listSelfChecks().filter{withinPeriod(it.date,period.selectedItem.toString())}; val cat=category.selectedItem.toString(); val relevant=if(cat=="All") ChecklistData.items else ChecklistData.items.filter{it.category==cat}; val ids=relevant.map{it.no}.toSet();
        var total=0;var pass=0;var fail=0;var na=0;var pending=0
        for(sc in records){ for(item in relevant){val r=db.getResponse(sc.id,item.no); when(r?.status){"Pass"->{pass++;total++};"Fail"->{fail++;total++};"N/A"->{na++;total++};else->{pending++}} } }
        val compliance=if(pass+fail==0)0.0 else pass*100.0/(pass+fail)
        addCard("Selected period","${records.size} self-check record(s)")
        addCard("Checklist scope","${relevant.size} point(s) in ${if(cat=="All")"all categories" else cat}")
        addCard("PASS / FAIL / N/A / Pending","$pass / $fail / $na / $pending")
        addCard("Compliance","${String.format("%.1f",compliance)}%")
        addCard("Open actions","${fail} failed point(s) require attention")
    }
    private fun addCard(title:String,value:String){val card=MaterialCardView(this).apply{useCompatPadding=true;radius=12f};val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14)};root.addView(TextView(this).apply{text=title;textSize=12f;setTextColor(android.graphics.Color.DKGRAY)});root.addView(TextView(this).apply{text=value;textSize=22f;setTypeface(typeface,1);setPadding(0,6,0,0)});card.addView(root);container.addView(card)}
    private fun withinPeriod(date:String,filter:String):Boolean{if(filter=="All")return true;return try{val d=SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).parse(date)!!;val c=Calendar.getInstance();val now=c.time; when(filter){"Today"->sameDay(d,now);"This Week"->{c.set(Calendar.DAY_OF_WEEK,c.firstDayOfWeek);val start=c.time;c.add(Calendar.DAY_OF_WEEK,6);d>=start&&d<=c.time};"This Month"->{c.set(Calendar.DAY_OF_MONTH,1);val start=c.time;c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));d>=start&&d<=c.time};"This Quarter"->{val month=c.get(Calendar.MONTH);val qStart=(month/3)*3;c.set(Calendar.MONTH,qStart);c.set(Calendar.DAY_OF_MONTH,1);val start=c.time;c.add(Calendar.MONTH,3);c.add(Calendar.DAY_OF_MONTH,-1);d>=start&&d<=c.time};"This Year"->{c.set(Calendar.DAY_OF_YEAR,1);val start=c.time;c.set(Calendar.MONTH,11);c.set(Calendar.DAY_OF_MONTH,31);d>=start&&d<=c.time};else->true}}catch(_:Exception){true}}
    private fun sameDay(a:Date,b:Date):Boolean{val c1=Calendar.getInstance();val c2=Calendar.getInstance();c1.time=a;c2.time=b;return c1.get(Calendar.YEAR)==c2.get(Calendar.YEAR)&&c1.get(Calendar.DAY_OF_YEAR)==c2.get(Calendar.DAY_OF_YEAR)}
}
