package com.whchecklist.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbHelper(context: Context) : SQLiteOpenHelper(context, "wh_checklist.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE self_checks(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, unit TEXT, user TEXT, type TEXT, status TEXT)")
        db.execSQL("CREATE TABLE responses(self_check_id INTEGER, checklist_no INTEGER, status TEXT, actual TEXT, remarks TEXT, gap TEXT, action TEXT, responsible TEXT, target_date TEXT, closure TEXT, photo_path TEXT, PRIMARY KEY(self_check_id, checklist_no))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE responses ADD COLUMN remarks TEXT DEFAULT ''")
    }
    fun createSelfCheck(date:String, unit:String, user:String, type:String): Long {
        val v=ContentValues().apply{put("date",date);put("unit",unit);put("user",user);put("type",type);put("status","Draft")}
        return writableDatabase.insert("self_checks",null,v)
    }
    fun saveResponse(id:Long,item:ChecklistItem,r:Response){
        val v=ContentValues().apply{
            put("self_check_id",id);put("checklist_no",item.no);put("status",r.status);put("actual",r.actual);put("remarks",r.remarks)
            put("gap",r.gap);put("action",r.action);put("responsible",r.responsible);put("target_date",r.targetDate);put("closure",r.closure);put("photo_path",r.photoPath)
        }
        writableDatabase.insertWithOnConflict("responses",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun getResponse(id:Long,no:Int):Response?{
        readableDatabase.rawQuery("SELECT status,actual,remarks,gap,action,responsible,target_date,closure,photo_path FROM responses WHERE self_check_id=? AND checklist_no=?",arrayOf(id.toString(),no.toString())).use{c->
            if(!c.moveToFirst())return null
            return Response(c.getString(0)?:("Pending"),c.getString(1)?:(""),c.getString(2)?:(""),c.getString(3)?:(""),c.getString(4)?:(""),c.getString(5)?:(""),c.getString(6)?:(""),c.getString(7)?:("Open"),if(c.isNull(8))null else c.getString(8))
        }
    }
    fun finishSelfCheck(id:Long){val v=ContentValues().apply{put("status","Completed")};writableDatabase.update("self_checks",v,"id=?",arrayOf(id.toString()))}
    fun listSelfChecks():List<SelfCheck>{
        val out=mutableListOf<SelfCheck>()
        readableDatabase.rawQuery("SELECT id,date,unit,user,type,status FROM self_checks ORDER BY id DESC",null).use{c->while(c.moveToNext()){
            val id=c.getLong(0);val s=getStats(id);out+=SelfCheck(id,c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),ChecklistData.items.size,s.completed,s.pass,s.fail,s.na,s.pending,s.compliance)
        }};return out
    }
    data class Stats(val completed:Int,val pass:Int,val fail:Int,val na:Int,val pending:Int,val compliance:Double)
    fun getStats(id:Long):Stats{
        var pass=0;var fail=0;var na=0;var completed=0
        readableDatabase.rawQuery("SELECT status FROM responses WHERE self_check_id=?",arrayOf(id.toString())).use{c->while(c.moveToNext()){
            when(c.getString(0)){"Yes","Pass"->{pass++;completed++};"No","Fail"->{fail++;completed++};"N/A"->{na++;completed++}}
        }}
        val pending=ChecklistData.items.size-completed
        val compliance=if(pass+fail==0)0.0 else pass*100.0/(pass+fail)
        return Stats(completed,pass,fail,na,pending,compliance)
    }
}
