package com.whchecklist.app

import android.content.Context
import android.net.Uri
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExcelExporter {
    fun export(context: Context, db: DbHelper, selfCheckId: Long, uri: Uri) {
        val sc=db.listSelfChecks().first{it.id==selfCheckId}
        val rows=mutableListOf<List<String>>()
        // Exact source layout: A Sr. No. | B Executive Checkpoints | C Frequency | D Actual Status Details | E Pass-1/Fail-0
        rows += listOf("Sr.n","EXECUTIVE CHECKPOINTS","Frequency","Actual Status Details","Pass -1 / Fail -0")
        var last=""
        for(item in ChecklistData.items){
            if(item.category!=last){rows+=listOf("",item.category,"","","");last=item.category}
            val r=db.getResponse(selfCheckId,item.no)
            val details=buildString{
                if(r!=null){
                    if(r.actual.isNotBlank())append(r.actual)
                    if(r.remarks.isNotBlank())append(if(isNotEmpty())" | " else "").append("Remarks: ").append(r.remarks)
                    if(r.gap.isNotBlank())append(" | Gap: ").append(r.gap)
                    if(r.action.isNotBlank())append(" | Action: ").append(r.action)
                    if(r.responsible.isNotBlank())append(" | Responsible: ").append(r.responsible)
                    if(r.targetDate.isNotBlank())append(" | Target: ").append(r.targetDate)
                }
            }
            val score=when(r?.status){"Yes","Pass"->"1";"No","Fail"->"0";else->""}
            rows+=listOf(item.no.toString(),item.text,item.frequency,details,score)
        }
        context.contentResolver.openOutputStream(uri)?.use{writeXlsx(rows,it)}
    }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun col(n:Int):String{var x=n;var s="";while(x>0){val r=(x-1)%26;s=('A'.code+r).toChar()+s;x=(x-1)/26};return s}
    private fun writeXlsx(rows:List<List<String>>,out:OutputStream){
        val shared=mutableListOf<String>();val idx=mutableMapOf<String,Int>();fun si(s:String)=idx.getOrPut(s){shared.add(s);shared.lastIndex}
        val sheet=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols><col min=\"1\" max=\"1\" width=\"9\"/><col min=\"2\" max=\"2\" width=\"70\"/><col min=\"3\" max=\"3\" width=\"14\"/><col min=\"4\" max=\"4\" width=\"85\"/><col min=\"5\" max=\"5\" width=\"14\"/></cols><sheetData>")
        rows.forEachIndexed{ri,row->val category=ri>0&&row[0].isBlank()&&row[1].isNotBlank();sheet.append("<row r=\"${ri+1}\"${if(category)" ht=\"22\"" else ""}>");if(category){sheet.append("<c r=\"B${ri+1}\" s=\"2\" t=\"s\"><v>${si(row[1])}</v></c>")}else{row.forEachIndexed{ci,v->sheet.append("<c r=\"${col(ci+1)}${ri+1}\" s=\"${if(ri==0)1 else 3}\" t=\"s\"><v>${si(v)}</v></c>")}};sheet.append("</row>")};sheet.append("</sheetData><mergeCells count=\"${rows.count{it[0].isBlank()&&it[1].isNotBlank()}}\">");rows.forEachIndexed{ri,row->if(ri>0&&row[0].isBlank()&&row[1].isNotBlank())sheet.append("<mergeCell ref=\"A${ri+1}:E${ri+1}\"/>")};sheet.append("</mergeCells></worksheet>")
        val sst=StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"${shared.size}\" uniqueCount=\"${shared.size}\">");shared.forEach{sst.append("<si><t>${esc(it)}</t></si>")};sst.append("</sst>")
        val wb="""<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Revised CE Checklist" sheetId="1" r:id="rId1"/></sheets></workbook>"""
        val rels="""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
        val wbrels="""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
        val types="""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"""
        val rootrels="""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
        val styles="""<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Aptos Display"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Aptos Display"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFFFF"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF075A8A"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/></border></borders><cellXfs count="4"><xf/><xf fontId="1" fillId="3" borderId="1" alignment horizontal="center" vertical="center" wrapText="1"/><xf fontId="1" fillId="3" borderId="1" alignment horizontal="left" vertical="center" wrapText="1"/><xf fontId="0" fillId="2" borderId="1" alignment vertical="top" wrapText="1"/></cellXfs></styleSheet>"""
        ZipOutputStream(out).use{z->fun put(n:String,t:String){z.putNextEntry(ZipEntry(n));z.write(t.toByteArray(Charsets.UTF_8));z.closeEntry()};put("[Content_Types].xml",types);put("_rels/.rels",rootrels);put("xl/workbook.xml",wb);put("xl/_rels/workbook.xml.rels",wbrels);put("xl/worksheets/sheet1.xml",sheet.toString());put("xl/sharedStrings.xml",sst.toString());put("xl/styles.xml",styles)}
    }
}
