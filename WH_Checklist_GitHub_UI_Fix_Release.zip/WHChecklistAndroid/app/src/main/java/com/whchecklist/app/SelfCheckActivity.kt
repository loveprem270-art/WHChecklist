package com.whchecklist.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.File
import androidx.core.content.FileProvider
import java.text.SimpleDateFormat
import java.util.*

class SelfCheckActivity : AppCompatActivity() {
    private lateinit var db: DbHelper
    private var selfCheckId=0L
    private lateinit var container: LinearLayout
    private lateinit var filterBar: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var spCategory: Spinner
    private lateinit var spFreq: Spinner
    private lateinit var spStatus: Spinner
    private lateinit var etSearch: EditText
    private lateinit var checklistScroll: ScrollView
    private lateinit var tvSessionSummary: TextView
    private lateinit var tvTypeLabel: TextView
    private var pendingPhotoItem:Int?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_self_check)
        db=DbHelper(this)
        findViewById<TextView>(R.id.btnBack).setOnClickListener{finish()}
        val typeList=listOf("Full Self-Check","Safety","Inward","Outward","Inventory / WMS","Security","Barcoding","APPS Tinting")
        findViewById<Spinner>(R.id.spType).adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,typeList)
        val etDate=findViewById<EditText>(R.id.etDate)
        etDate.setText(SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date()))
        etDate.setOnClickListener{showDatePicker(etDate)}
        container=findViewById(R.id.checklistContainer);filterBar=findViewById(R.id.filterBar);progress=findViewById(R.id.progress);tvProgress=findViewById(R.id.tvProgress)
        checklistScroll=findViewById(R.id.checklistScroll);tvSessionSummary=findViewById(R.id.tvSessionSummary);tvTypeLabel=findViewById(R.id.tvTypeLabel)
        spCategory=findViewById(R.id.spCategory);spFreq=findViewById(R.id.spFreq);spStatus=findViewById(R.id.spStatus);etSearch=findViewById(R.id.etSearch)
        spCategory.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("All")+ChecklistData.items.map{it.category}.distinct())
        spFreq.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("All","Daily","Weekly","Fortnightly","Monthly","Quarterly","Annually","As & When"))
        spStatus.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("All","Pending","Yes","No","N/A"))
        val listener=object:AdapterView.OnItemSelectedListener{override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long)=render();override fun onNothingSelected(p:AdapterView<*>?)=Unit}
        spCategory.onItemSelectedListener=listener;spFreq.onItemSelectedListener=listener;spStatus.onItemSelectedListener=listener
        etSearch.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int)=Unit;override fun onTextChanged(s:CharSequence?,b:Int,c:Int,a:Int)=render();override fun afterTextChanged(e:android.text.Editable?)=Unit})
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnStart).setOnClickListener{startOrResume()}
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnExport).setOnClickListener{if(selfCheckId>0)createExport()else toast("Start a self-check first")}
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnComplete).setOnClickListener{complete()}
        val existing=intent.getLongExtra("selfCheckId",0L);if(existing>0){selfCheckId=existing;loadExisting(existing)}
    }

    private fun loadExisting(id:Long){
        val saved=db.listSelfChecks().firstOrNull{it.id==id}?:return
        findViewById<EditText>(R.id.etUnit).setText(saved.unit);findViewById<EditText>(R.id.etUser).setText(saved.user);findViewById<EditText>(R.id.etDate).setText(saved.date)
        val typeAdapter=findViewById<Spinner>(R.id.spType).adapter
        val typeIndex=(0 until (typeAdapter?.count ?: 0)).firstOrNull { typeAdapter?.getItem(it)?.toString()==saved.type } ?: 0
        findViewById<Spinner>(R.id.spType).setSelection(typeIndex)
        findViewById<TextView>(R.id.tvSelfCheckId).text="Self-Check #$id • ${saved.unit}"
        findViewById<EditText>(R.id.etUnit).isEnabled=false;findViewById<EditText>(R.id.etUser).isEnabled=false;findViewById<EditText>(R.id.etDate).isEnabled=false;findViewById<Spinner>(R.id.spType).isEnabled=false
        showCompactChecklistHeader();filterBar.visibility=View.VISIBLE;render()
    }

    private fun showDatePicker(target:EditText){
        val c=Calendar.getInstance()
        DatePickerDialog(this,{_,y,m,d->target.setText(String.format("%02d-%02d-%04d",d,m+1,y))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun startOrResume(){
        if(selfCheckId>0){filterBar.visibility=View.VISIBLE;render();return}
        val unit=findViewById<EditText>(R.id.etUnit).text.toString().trim();val user=findViewById<EditText>(R.id.etUser).text.toString().trim();val date=findViewById<EditText>(R.id.etDate).text.toString().trim();val type=findViewById<Spinner>(R.id.spType).selectedItem.toString()
        if(unit.isBlank()||user.isBlank()||date.isBlank()){toast("Please enter Unit, Self-Checker and Date");return}
        selfCheckId=db.createSelfCheck(date,unit,user,type);findViewById<TextView>(R.id.tvSelfCheckId).text="Self-Check #$selfCheckId • $unit"
        findViewById<EditText>(R.id.etUnit).isEnabled=false;findViewById<EditText>(R.id.etUser).isEnabled=false;findViewById<EditText>(R.id.etDate).isEnabled=false;findViewById<Spinner>(R.id.spType).isEnabled=false
        hideKeyboard();showCompactChecklistHeader();filterBar.visibility=View.VISIBLE;render()
    }

    private fun showCompactChecklistHeader(){
        val unit=findViewById<EditText>(R.id.etUnit).text.toString().trim()
        val user=findViewById<EditText>(R.id.etUser).text.toString().trim()
        val date=findViewById<EditText>(R.id.etDate).text.toString().trim()
        val type=findViewById<Spinner>(R.id.spType).selectedItem?.toString().orEmpty()
        findViewById<View>(R.id.tilUnit).visibility=View.GONE
        findViewById<View>(R.id.tilUser).visibility=View.GONE
        findViewById<View>(R.id.tilDate).visibility=View.GONE
        tvTypeLabel.visibility=View.GONE
        findViewById<View>(R.id.spType).visibility=View.GONE
        findViewById<View>(R.id.btnStart).visibility=View.GONE
        tvSessionSummary.text="${unit.ifBlank{"Warehouse"}}  •  ${user.ifBlank{"Self-Checker"}}  •  $date  •  $type"
        tvSessionSummary.visibility=View.VISIBLE
    }

    private fun hideKeyboard(){
        val imm=getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let{imm.hideSoftInputFromWindow(it.windowToken,0);it.clearFocus()}
    }

    private fun render(){
        if(selfCheckId<=0)return
        container.removeAllViews()
        val area=spCategory.selectedItem?.toString()?:"All";val freq=spFreq.selectedItem?.toString()?:"All";val statusFilter=spStatus.selectedItem?.toString()?:"All";val q=etSearch.text.toString().trim().lowercase(Locale.getDefault())
        var lastCat="";var shown=0
        for(item in ChecklistData.items){
            val r=db.getResponse(selfCheckId,item.no);val st=r?.status?:"Pending"
            if(area!="All"&&item.category!=area)continue
            if(freq!="All"&&item.frequency!=freq)continue
            if(statusFilter!="All"&&st!=statusFilter)continue
            if(q.isNotBlank()&&!item.text.lowercase(Locale.getDefault()).contains(q)&&!item.category.lowercase(Locale.getDefault()).contains(q))continue
            if(item.category!=lastCat){
                lastCat=item.category
                container.addView(TextView(this).apply{text=item.category;textSize=15f;setTextColor(Color.WHITE);setTypeface(typeface,1);setPadding(14,12,14,12);setBackgroundColor(Color.rgb(7,90,138));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(-1,52).apply{topMargin=10})
            }
            container.addView(createItemCard(item,r));shown++
        }
        val s=db.getStats(selfCheckId);progress.max=ChecklistData.items.size;progress.progress=s.completed;tvProgress.text="${s.completed} / ${ChecklistData.items.size} completed • ${String.format(Locale.getDefault(),"%.1f",s.compliance)}% compliance • ${s.fail} failed • ${s.pending} pending"
        if(shown==0)container.addView(TextView(this).apply{text="No checklist items match the selected filters.";setPadding(12,20,12,20)})
        checklistScroll.post {
            if (s.completed < ChecklistData.items.size && statusFilter == "All" && q.isBlank()) {
                checklistScroll.smoothScrollTo(0, (container.top - 12).coerceAtLeast(0))
            }
        }
    }

    private fun createItemCard(item:ChecklistItem,r:Response?):View{
        val card=MaterialCardView(this).apply{radius=14f;cardElevation=2f;useCompatPadding=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text="${item.no}. ${item.text}";textSize=15f;setTypeface(typeface,1);setTextColor(Color.rgb(25,35,45))}
        head.addView(title,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f))
        val tick=TextView(this).apply{text=when(r?.status){"Yes"->"✓","No"->"✕","N/A"->"—",else->"○"};textSize=24f;setTextColor(when(r?.status){"Yes"->Color.rgb(25,135,84);"No"->Color.rgb(192,57,43);else->Color.GRAY});gravity=Gravity.CENTER;setPadding(8,0,0,0)}
        head.addView(tick,LinearLayout.LayoutParams(38,38));root.addView(head)
        root.addView(TextView(this).apply{text="${item.category}  •  ${item.frequency}";textSize=11f;setTextColor(Color.DKGRAY);setPadding(0,4,0,8)})

        val spec=InputSpecs.forItem(item.no)
        val values=decodeFields(r?.actual?:(""))
        val fieldViews=mutableMapOf<String,View>()
        spec.forEach{fs->
            val fieldView=addField(root,fs,values[fs.key].orEmpty()){key,value->
                values[key]=value
                persistActual(item,values)
            }
            fieldViews[fs.key]=fieldView
        }

        root.addView(TextView(this).apply{text="ACTUAL STATUS";textSize=12f;setTypeface(typeface,1);setTextColor(Color.rgb(60,70,80));setPadding(0,10,0,4)})
        val statusRow=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val statuses=listOf("Yes","No","N/A")
        statuses.forEach{v->
            val rb=RadioButton(this).apply{text=if(v=="Yes")"✓ YES"else if(v=="No")"✕ NO"else"N/A";textSize=13f;isChecked=r?.status==v;setPadding(6,0,12,0);setOnClickListener{saveStatus(item,v)}}
            statusRow.addView(rb,RadioGroup.LayoutParams(0,50,1f))
        }
        root.addView(statusRow)

        root.addView(TextView(this).apply{text="REMARKS (can be entered even when YES)";textSize=12f;setTypeface(typeface,1);setPadding(0,8,0,3)})
        val remarks=TextInputEditText(this).apply{hint="Enter remarks / explanation";setText(r?.remarks.orEmpty());minLines=2;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;setOnFocusChangeListener{_,has->if(!has)saveRemarks(item,this)}}
        val remarksTil=TextInputLayout(this).apply{hint="Remarks";addView(remarks)};root.addView(remarksTil)

        val photo=Button(this).apply{text=if(r?.photoPath.isNullOrBlank())"📷  ADD PHOTO"else"📷  PHOTO ATTACHED";isAllCaps=false;setOnClickListener{capturePhoto(item.no)}}
        root.addView(photo,LinearLayout.LayoutParams(-1,48).apply{topMargin=6})
        if(r?.status=="No"){
            val fail=TextView(this).apply{text="PASS-1 / FAIL-0: 0";textSize=12f;setTextColor(Color.rgb(192,57,43));setTypeface(typeface,1);setPadding(0,6,0,2)};root.addView(fail)
            val action=TextView(this).apply{text="Corrective action: ${r.action.ifBlank{"Pending"}}";textSize=11f;setTextColor(Color.DKGRAY)};root.addView(action)
            root.addView(Button(this).apply{text="EDIT GAP / CORRECTIVE ACTION";isAllCaps=false;setOnClickListener{showNoDialog(item,r)}})
        } else if(r?.status=="Yes") {
            root.addView(TextView(this).apply{text="PASS-1 / FAIL-0: 1";textSize=12f;setTextColor(Color.rgb(25,135,84));setTypeface(typeface,1);setPadding(0,6,0,0)})
        }
        card.addView(root)
        return card
    }

    private fun addField(parent:LinearLayout,spec:FieldSpec,value:String,onChange:(String,String)->Unit):View{
        val label=TextView(this).apply{text=spec.label;textSize=11f;setTextColor(Color.rgb(85,95,105));setPadding(0,6,0,2)};parent.addView(label)
        return when(spec.kind){
            FieldKind.TEXT,FieldKind.NUMBER,FieldKind.PERCENT,FieldKind.CURRENCY -> {
                val til=TextInputLayout(this).apply{hint=when(spec.kind){FieldKind.NUMBER->"Enter number";FieldKind.PERCENT->"Enter %";FieldKind.CURRENCY->"Enter INR value";else->"Enter ${spec.label.lowercase(Locale.getDefault())}"}}
                val e=TextInputEditText(this).apply{setText(value);minLines=1;inputType=if(spec.kind==FieldKind.TEXT)InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;setOnFocusChangeListener{_,has->if(!has)onChange(spec.key,text.toString())}}
                til.addView(e);parent.addView(til,LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{bottomMargin=4});e
            }
            FieldKind.DATE -> {
                val b=Button(this).apply{text=if(value.isBlank())"SELECT DATE" else value;isAllCaps=false;setOnClickListener{val c=Calendar.getInstance();DatePickerDialog(this@SelfCheckActivity,{_,y,m,d->val v=String.format("%02d-%02d-%04d",d,m+1,y);text=v;onChange(spec.key,v)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}}
                parent.addView(b,LinearLayout.LayoutParams(-1,48).apply{bottomMargin=4});b
            }
            FieldKind.TIME -> {
                val b=Button(this).apply{text=if(value.isBlank())"SELECT TIME" else value;isAllCaps=false;setOnClickListener{val c=Calendar.getInstance();TimePickerDialog(this@SelfCheckActivity,{_,h,m->val v=String.format("%02d:%02d",h,m);text=v;onChange(spec.key,v)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()}}
                parent.addView(b,LinearLayout.LayoutParams(-1,48).apply{bottomMargin=4});b
            }
            FieldKind.YES_NO -> {
                val rg=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
                listOf("Yes","No").forEach{v->val rb=RadioButton(this).apply{text=v;isChecked=value==v;setOnClickListener{onChange(spec.key,v)}};rg.addView(rb,RadioGroup.LayoutParams(0,48,1f))}
                parent.addView(rg,LinearLayout.LayoutParams(-1,48).apply{bottomMargin=4});rg
            }
            FieldKind.CHOICE -> {
                val sp=Spinner(this);val options=listOf("")+spec.options;sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options);val idx=options.indexOf(value);if(idx>=0)sp.setSelection(idx);sp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(pos>0)onChange(spec.key,options[pos])};override fun onNothingSelected(p:AdapterView<*>?)=Unit};parent.addView(sp,LinearLayout.LayoutParams(-1,48).apply{bottomMargin=4});sp
            }
        }
    }

    private fun saveStatus(item:ChecklistItem,status:String){
        val old=db.getResponse(selfCheckId,item.no)?:Response()
        db.saveResponse(selfCheckId,item,old.copy(status=status))
        if(status=="No")showNoDialog(item,old.copy(status="No")) else render()
    }

    private fun showNoDialog(item:ChecklistItem,old:Response){
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,0,8,0)}
        val gap=EditText(this).apply{hint="Gap / observation";setText(old.gap);minLines=2}
        val action=EditText(this).apply{hint="Corrective action";setText(old.action);minLines=2}
        val resp=EditText(this).apply{hint="Responsible person";setText(old.responsible)}
        val target=EditText(this).apply{hint="Target date (DD-MM-YYYY)";setText(old.targetDate)}
        val options=listOf("Open","In Progress","Closed");val closure=Spinner(this).apply{adapter=ArrayAdapter(this@SelfCheckActivity,android.R.layout.simple_spinner_dropdown_item,options);setSelection(options.indexOf(old.closure).coerceAtLeast(0))}
        l.addView(gap);l.addView(action);l.addView(resp);l.addView(target);l.addView(closure)
        MaterialAlertDialogBuilder(this).setTitle("NO / FAILED ITEM #${item.no}").setView(l).setPositiveButton("SAVE"){_,_->db.saveResponse(selfCheckId,item,old.copy(status="No",gap=gap.text.toString(),action=action.text.toString(),responsible=resp.text.toString(),targetDate=target.text.toString(),closure=closure.selectedItem.toString()));render()}.setNegativeButton("CANCEL",null).show()
    }

    private fun persistActual(item:ChecklistItem,values:MutableMap<String,String>){
        val old=db.getResponse(selfCheckId,item.no)?:Response();db.saveResponse(selfCheckId,item,old.copy(actual=encodeFields(values)))
    }
    private fun decodeFields(s:String):MutableMap<String,String>{
        val out=mutableMapOf<String,String>();if(s.isBlank())return out
        s.split(";;").forEach{part->val p=part.indexOf('=');if(p>0)out[part.substring(0,p)]=part.substring(p+1)};return out
    }
    private fun encodeFields(m:Map<String,String>)=m.filterValues{it.isNotBlank()}.entries.joinToString(";;"){it.key+"="+it.value.replace(";","/").replace("=","-")}
    private fun saveRemarks(item:ChecklistItem,e:EditText){val old=db.getResponse(selfCheckId,item.no)?:Response();db.saveResponse(selfCheckId,item,old.copy(remarks=e.text.toString()))}

    private fun capturePhoto(itemNo:Int){pendingPhotoItem=itemNo;val i=Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);if(i.resolveActivity(packageManager)!=null)startActivityForResult(i,777)else toast("Camera not available")}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==888&&resultCode==RESULT_OK&&data?.data!=null){ExcelExporter.export(this,db,selfCheckId,data.data!!);toast("Excel exported");return}
        if(requestCode==777&&resultCode==RESULT_OK){val no=pendingPhotoItem?:return;val b=data?.extras?.get("data") as? android.graphics.Bitmap?:return;val dir=File(getExternalFilesDir("photos"),"").apply{mkdirs()};val f=File(dir,"sc_${selfCheckId}_$no.jpg");f.outputStream().use{b.compress(android.graphics.Bitmap.CompressFormat.JPEG,85,it)};val old=db.getResponse(selfCheckId,no)?:Response();db.saveResponse(selfCheckId,ChecklistData.items.first{it.no==no},old.copy(photoPath=f.absolutePath));render()}
    }
    private fun complete(){
        if(selfCheckId<=0){toast("Start a self-check first");return}
        val s=db.getStats(selfCheckId)
        if(s.pending>0)MaterialAlertDialogBuilder(this).setTitle("Pending checklist items").setMessage("${s.pending} items are still pending. Complete anyway?").setNegativeButton("Continue checking",null).setPositiveButton("Complete"){_,_->db.finishSelfCheck(selfCheckId);toast("Self-check completed")}.show()
        else{db.finishSelfCheck(selfCheckId);toast("Self-check completed")}
    }
    private fun createExport(){
        if(selfCheckId<=0){toast("Start a self-check first");return}
        try {
            val dir=File(cacheDir,"exports").apply{mkdirs()}
            val file=File(dir,"WH_Checklist_${selfCheckId}_${System.currentTimeMillis()}.xlsx")
            val uri=FileProvider.getUriForFile(this,"${BuildConfig.APPLICATION_ID}.fileprovider",file)
            ExcelExporter.export(this,db,selfCheckId,uri)
            val share=Intent(Intent.ACTION_SEND).apply{
                type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putExtra(Intent.EXTRA_SUBJECT,"WH Checklist Self-Check #$selfCheckId")
            }
            startActivity(Intent.createChooser(share,"Share WH Checklist Excel"))
        } catch(e:Exception){ toast("Unable to prepare Excel: ${e.message}") }
    }
    private fun toast(m:String)=Toast.makeText(this,m,Toast.LENGTH_SHORT).show()
}
