# WH Checklist – Android Studio Project

## Current version
**Column-D Structured Inputs v3**

This version was prepared from the 7-page scanned Revised CE Checklist supplied in the conversation. The source shows 146 numbered checkpoints and Column D contains the expected Actual Status Details format for each checkpoint. The app now uses an explicit structured input definition for **all 146 checklist numbers** instead of one generic text field.

## App
- Name: **WH Checklist**
- Classic Android XML/View UI
- Offline-first local SQLite storage
- Self-Check terminology only; no Audit/Auditor workflow
- Checklist completion indicator and progress
- YES / NO / N/A actual status
- YES remains eligible for Remarks
- NO opens Gap / Corrective Action / Responsible Person / Target Date / Closure
- Optional photo evidence

## Column-D structured controls
Each of the 146 questions has an explicit `InputSpecs.forItem(no)` definition.
Supported controls:
- Text
- Number / quantity
- Percentage
- Currency / INR value
- Date picker
- Time picker
- Yes / No
- Source-style choice lists such as Working/Not working, Good/Needs repair, Pending/Approved/Rejected, Active/Expired, etc.

The resulting values are stored as labelled Actual Status Details and can be exported without losing the individual fields.

A maintenance reference is included at:
`app/src/main/assets/checklist_input_controls.csv`

## Excel export
The app exports **one worksheet only**, matching the source checklist structure:

| Column | Source heading |
|---|---|
| A | Sr.n |
| B | EXECUTIVE CHECKPOINTS |
| C | Frequency |
| D | Actual Status Details |
| E | Pass -1 / Fail -0 |

Category headings are preserved as blue section rows and merged across A:E. Remarks and, where applicable, corrective-action information remain in Column D so no additional report sheets are introduced.

YES = 1, NO = 0, N/A/Pending = blank in Column E.

## Build
Open the `WHChecklistAndroid` folder in Android Studio, allow Gradle sync, then use **Build > Build APK(s)**.

The local environment used to prepare this source package does not contain a configured Android SDK/Gradle build toolchain, so the APK is not falsely represented as precompiled. The project source has been checked for the standalone Kotlin checklist/spec data compilation.
