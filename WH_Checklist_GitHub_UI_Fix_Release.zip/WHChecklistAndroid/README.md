# WH Checklist – Android Studio Project

Application name: **WH Checklist**

Style: classic XML/View-based Android UI (not Compose).

Core purpose: offline C&F / warehouse self-check based on the Revised CE Checklist, with 146 checklist points.

## Included
- Classic Android XML UI
- Checklist-style launcher icon
- Offline SQLite storage for self-checks and responses
- 146 embedded checklist master points
- Category, frequency, status and text filters
- PASS / FAIL / N/A buttons with visible state
- Observation and corrective-action fields for failed items
- Optional offline photo capture
- Saved self-check records
- One-sheet `.xlsx` export using the source workbook structure: columns A-D = No., Checklist, Frequency, Actual Input; category rows are inserted between sections
- No cloud dependency

## Excel output design
The export intentionally uses **one worksheet only**, named `Revised CE Checklist`, matching the source attachment's visible structure. It does not add summary sheets.

## Build
Open the folder in Android Studio, allow Gradle sync, then Build > Make Project. Use Run or Build > Build APK(s).

If Android Studio reports a plugin/JDK mismatch, use JDK 17 and an Android Studio version compatible with Android Gradle Plugin 8.6.1.

## UI Fix Release
The current release includes UI/navigation usability fixes only. The 146 checklist activities are treated as locked. See `UI_FIX_RELEASE_NOTES.md`.

## Build environment
Use JDK 21 with Gradle 8.7. JDK 25 is not compatible with this Gradle version.
