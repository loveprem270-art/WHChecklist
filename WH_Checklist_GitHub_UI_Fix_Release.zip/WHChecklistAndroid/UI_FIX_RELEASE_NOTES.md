WH Checklist - UI Fix Release

This release keeps the existing 146 checklist activities/configuration unchanged.

UI fixes included:
1. After START/RESUME, the setup fields collapse into a compact session summary so the first checklist item is visible immediately.
2. Keyboard is dismissed when starting the self-check.
3. Screen uses resize/scroll-safe behavior for phone keyboards.
4. Existing Self-Check navigation remains intact.
5. Excel export now uses the Android Share Sheet so the user can choose WhatsApp, email, Drive, Teams, etc., instead of only saving through a document picker.
6. Excel data mapping and checklist wording were not changed by this UI release.

Important: Test the project in Android Studio before production use. The project uses Gradle 8.7 and should be built with JDK 21 (not JDK 25).
